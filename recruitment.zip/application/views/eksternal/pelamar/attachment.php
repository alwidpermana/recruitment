<label class="mb-3">&nbsp;</label>
<div class="card shadow-none border">
  <div class="p-1">
      <div class="row align-items-center">
          <div class="col-auto">
              <div class="sw-4 sh-4 me-1 d-inline-block bg-primary d-flex justify-content-center align-items-center rounded-md">
                <div class="fw-bold text-alternate">AA</div>
              </div>
          </div>
          <div class="col ps-0">
              <a href="javascript:void(0);" class="text-muted fw-bold">-</a>
              <p class="mb-0 font-12">10 MB</p>
          </div>
          <div class="col-auto">
              <!-- Button -->
              <a href="javascript:void(0);" class="btn btn-link font-16 text-muted">
                  <i data-acorn-icon="download" class="icon" data-acorn-size="18"></i>
              </a>
          </div>
      </div>
  </div>
</div>