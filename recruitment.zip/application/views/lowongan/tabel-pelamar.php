<table class="data-table nowrap hover" style="width: 100%;" id="datatable">
  <thead>
    <tr>
      <th class="text-muted text-small text-uppercase">No</th>
      <th class="text-muted text-small text-uppercase">Foto</th>
      <th class="text-muted text-small text-uppercase ">Nama Lengkap</th>
      <th class="text-muted text-small text-uppercase">No KTP</th>
      <th class="text-muted text-small text-uppercase"></th>
    </tr>
  </thead>
  <tbody>
    
  </tbody>
</table>